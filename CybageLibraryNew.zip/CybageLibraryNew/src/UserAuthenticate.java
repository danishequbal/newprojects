

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class UserAuthenticate
 */
@WebServlet("/UserAuthenticate")
public class UserAuthenticate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserAuthenticate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		
		PrintWriter out=response.getWriter();
		try 
        {
            
            HttpSession se1=request.getSession();
            
             String usn=request.getParameter("uid");
             String pwd=request.getParameter("pwd");
        
           
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb","root","password");
            
            PreparedStatement pst1=con.prepareStatement("select * from userdetails where uid='"+usn+"' and password='"+pwd+"'");
            ResultSet rs1=pst1.executeQuery();
            if(rs1.next())      
            {
            	HttpSession se=request.getSession(true);
                                  if(rs1.getString(4).equals("user"))
                                  {
                   
                                        
                              
                                        
                                            se.setAttribute("uname",rs1.getString(2));
                                            se.setAttribute("uid",rs1.getString(1));
                                            
                                           RequestDispatcher rd=request.getRequestDispatcher("userhome.jsp");
                                           rd.forward(request, response);
                                            //response.sendRedirect("userhome.jsp");
                                  }
                                  else
                                  {
                                	  se.setAttribute("umessage","You are wrong login section");
                                      RequestDispatcher rd=request.getRequestDispatcher("userlogin.jsp");
                                      rd.forward(request, response);
                                	  
                                  }
                        
                                        
                
          
            }
            else
            {
                 se1.setAttribute("umessage","Username/Password is invalid");
                 RequestDispatcher rd=request.getRequestDispatcher("userlogin.jsp");
                 rd.forward(request, response);
            }
            
        }
        catch(Exception e)
        {
            out.println(e);
        }
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
